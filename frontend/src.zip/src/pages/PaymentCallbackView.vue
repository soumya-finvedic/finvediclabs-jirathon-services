<!-- src/pages/PaymentCallbackView.vue -->
<template>
  <div class="p-6 max-w-xl mx-auto text-center">
    <div v-if="processing" class="card p-8">
      <p class="text-lg font-semibold mb-2">Confirming your registration...</p>
      <p class="text-sm text-gray-500">Please wait, do not close this tab.</p>
    </div>

    <div v-else-if="confirmed" class="card p-8">
      <p class="text-2xl font-bold text-green-600 mb-2">Registration Confirmed!</p>
      <p class="text-gray-600 mb-4">Your payment was successful and your slot is confirmed.</p>
      <RouterLink to="/contests" class="btn-primary">Back to Contests</RouterLink>
    </div>

    <div v-else-if="failed" class="card p-8">
      <p class="text-2xl font-bold text-red-600 mb-2">Payment Failed</p>
      <p class="text-gray-600 mb-4">{{ errorMessage }}</p>
      <RouterLink :to="`/contests/${contestId}`" class="btn-secondary">Try Again</RouterLink>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { contestAPI, paymentAPI } from '@/api'
import { useUserStore } from '@/stores'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const processing = ref(true)
const confirmed = ref(false)
const failed = ref(false)
const errorMessage = ref('')
const contestId = ref('')

onMounted(async () => {
  const status = route.query.status
  const registrationId = route.query.udf1
  contestId.value = route.query.udf2 || ''

  // Guard: if not authenticated, save params and redirect to login
  if (!userStore.isAuthenticated) {
    router.push({
      name: 'Login',
      query: { redirect: route.fullPath }   // comes back here after login
    })
    return
  }

  if (!status || !registrationId) {
    failed.value = true
    errorMessage.value = 'Missing payment information. Please contact support.'
    processing.value = false
    return
  }

  if (String(status).toLowerCase() !== 'success') {
    failed.value = true
    errorMessage.value = 'Payment was not successful. Please try again.'
    processing.value = false
    return
  }

  try {
    const paymentRes = await paymentAPI.getByRegistration(registrationId)
    const transactionId = paymentRes?.data?.data?.id

    if (!transactionId) throw new Error('Could not find payment record')

    await contestAPI.confirmPayment(registrationId, transactionId)
    confirmed.value = true
  } catch (err) {
    failed.value = true
    errorMessage.value = err.response?.data?.error || err.message || 'Failed to confirm registration.'
  } finally {
    processing.value = false
  }
})
</script>