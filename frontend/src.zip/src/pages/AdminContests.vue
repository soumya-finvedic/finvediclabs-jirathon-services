<template>
  <div class="p-6 max-w-7xl mx-auto space-y-6">
    <div class="flex items-center justify-between gap-3">
      <h1 class="text-3xl font-bold text-gray-900 dark:text-gray-100">Manage Contests</h1>
      <button class="btn-secondary" :disabled="loading" @click="loadContests">
        {{ loading ? 'Refreshing...' : 'Refresh' }}
      </button>
    </div>

    <div v-if="error" class="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-red-700">
      {{ error }}
    </div>
    <div v-if="success" class="rounded-lg border border-green-200 bg-green-50 px-4 py-3 text-green-700">
      {{ success }}
    </div>

    <div class="card p-6 space-y-4">
      <div class="flex items-center justify-between">
        <h2 class="text-xl font-semibold text-gray-900 dark:text-gray-100">
          {{ editingId ? 'Edit Contest' : 'Create Contest' }}
        </h2>
        <button v-if="editingId" class="btn-ghost" @click="resetForm">Cancel Edit</button>
      </div>

      <form class="grid grid-cols-1 md:grid-cols-2 gap-4" @submit.prevent="submitContest">
        <div class="space-y-1 md:col-span-2">
          <label class="text-sm font-medium">Title</label>
          <input v-model.trim="form.title" class="input" required maxlength="120" />
        </div>

        <div class="space-y-1">
          <label class="text-sm font-medium">Slug</label>
          <input v-model.trim="form.slug" class="input" required maxlength="80" pattern="^[a-z0-9]+(?:-[a-z0-9]+)*$" />
          <p class="text-xs text-gray-500">lowercase and hyphen-separated</p>
        </div>

        <div class="space-y-1">
          <label class="text-sm font-medium">Contest Type</label>
          <select v-model="form.contestType" class="select" required>
            <option value="INDIVIDUAL">INDIVIDUAL</option>
            <option value="TEAM">TEAM</option>
          </select>
        </div>

        <div class="space-y-1 md:col-span-2">
          <label class="text-sm font-medium">Description</label>
          <textarea v-model.trim="form.description" class="textarea min-h-24" required maxlength="5000" />
        </div>

        <div class="space-y-1 md:col-span-2">
          <label class="text-sm font-medium">Rules (one per line)</label>
          <textarea v-model="form.rulesText" class="textarea min-h-24" required placeholder="Rule 1&#10;Rule 2" />
        </div>

        <div class="space-y-1 md:col-span-2">
          <label class="text-sm font-medium">Supported Languages (comma-separated)</label>
          <input v-model.trim="form.supportedLanguagesText" class="input" required placeholder="java, python, cpp" />
          <p v-if="supportedLanguages.length" class="text-xs text-gray-500">
            Supported by backend: {{ supportedLanguages.join(', ') }}
          </p>
        </div>

        <div class="space-y-1">
          <label class="text-sm font-medium">Start Time</label>
          <input v-model="form.startTime" class="input" type="datetime-local" required />
        </div>

        <div class="space-y-1">
          <label class="text-sm font-medium">End Time</label>
          <input v-model="form.endTime" class="input" type="datetime-local" required />
        </div>

        <div class="space-y-1">
          <label class="text-sm font-medium">Registration Fee</label>
          <input v-model.number="form.registrationFee" class="input" type="number" min="0" step="0.01" required />
        </div>

        <div v-if="editingId" class="space-y-1">
          <label class="text-sm font-medium">Status</label>
          <select v-model="form.status" class="select">
            <option value="DRAFT">DRAFT</option>
            <option value="PUBLISHED">PUBLISHED</option>
            <option value="ARCHIVED">ARCHIVED</option>
          </select>
        </div>

        <div class="md:col-span-2 flex justify-end">
          <button class="btn-primary" :disabled="submitting">
            {{ submitting ? 'Saving...' : (editingId ? 'Update Contest' : 'Create Contest') }}
          </button>
        </div>
      </form>
    </div>

    <div class="card overflow-hidden">
      <div class="table-responsive">
        <table class="table w-full">
          <thead>
            <tr>
              <th>Title</th>
              <th>Type</th>
              <th>Status</th>
              <th>Fee</th>
              <th>Start</th>
              <th>End</th>
              <th>Created</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-if="!loading && contests.length === 0">
              <td colspan="8" class="text-center text-gray-500">No contests found</td>
            </tr>
            <tr v-for="contest in contests" :key="contest.id">
              <td class="font-medium">{{ contest.title }}</td>
              <td>{{ contest.contestType }}</td>
              <td>
                <span class="badge" :class="statusClass(contest.status)">{{ contest.status }}</span>
              </td>
              <td>{{ Number(contest.registrationFee || 0).toFixed(2) }}</td>
              <td>{{ formatDate(contest.startTime) }}</td>
              <td>{{ formatDate(contest.endTime) }}</td>
              <td>{{ formatDate(contest.createdAt) }}</td>
              <td class="whitespace-nowrap">
                <button class="btn-ghost text-sm" @click="startEdit(contest)">Edit</button>
                <button class="btn-ghost text-sm text-red-600" :disabled="submitting" @click="deleteContest(contest)">Delete</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script setup>
import { onMounted, ref, watch } from 'vue'
import { adminContestAPI } from '@/api'

const contests = ref([])
const supportedLanguages = ref([])
const loading = ref(false)
const submitting = ref(false)
const editingId = ref('')
const error = ref('')
const success = ref('')

const initialForm = () => ({
  title: '',
  slug: '',
  description: '',
  rulesText: '',
  contestType: 'INDIVIDUAL',
  supportedLanguagesText: 'java, python',
  startTime: '',
  endTime: '',
  registrationFee: 0,
  status: 'DRAFT'
})

const form = ref(initialForm())

const formatDate = (value) => {
  if (!value) return '-'
  return new Date(value).toLocaleString()
}

const toLocalDateTimeInput = (value) => {
  if (!value) return ''
  const date = new Date(value)
  const timezoneOffsetMs = date.getTimezoneOffset() * 60000
  return new Date(date.getTime() - timezoneOffsetMs).toISOString().slice(0, 16)
}

const parseDateTime = (value) => {
  if (!value) return null

  const trimmed = String(value).trim()
  if (!trimmed) return null

  const direct = new Date(trimmed)
  if (!Number.isNaN(direct.getTime())) {
    return direct
  }

  const match = trimmed.match(/^(\d{2})-(\d{2})-(\d{4})\s+(\d{2}):(\d{2})$/)
  if (match) {
    const [, dd, mm, yyyy, hh, min] = match
    const parsed = new Date(Number(yyyy), Number(mm) - 1, Number(dd), Number(hh), Number(min))
    if (!Number.isNaN(parsed.getTime())) {
      return parsed
    }
  }

  return null
}

const toIso = (value) => {
  const parsed = parseDateTime(value)
  return parsed ? parsed.toISOString() : null
}

const normalizeSlug = (value) => value
  .toLowerCase()
  .trim()
  .replace(/[^a-z0-9\s-]/g, '')
  .replace(/\s+/g, '-')
  .replace(/-+/g, '-')
  .replace(/^-|-$/g, '')

watch(() => form.value.title, (newTitle) => {
  if (!editingId.value) {
    form.value.slug = normalizeSlug(newTitle)
  }
})

const parseRules = (text) => text
  .split('\n')
  .map((line) => line.trim())
  .filter(Boolean)

const parseLanguages = (text) => [...new Set(
  text
    .split(',')
    .map((item) => item.trim())
    .filter(Boolean)
)]

const statusClass = (status) => {
  return {
    DRAFT: 'badge-warning',
    PUBLISHED: 'badge-success',
    ARCHIVED: 'badge-danger'
  }[status] || 'badge-info'
}

const extractErrorMessage = (err, fallback = 'Request failed') => {
  return err?.response?.data?.error || err?.response?.data?.message || err?.message || fallback
}

const loadSupportedLanguages = async () => {
  try {
    const response = await adminContestAPI.getSupportedLanguages()
    const data = response?.data?.data
    if (Array.isArray(data)) {
      supportedLanguages.value = data
    }
  } catch (_) {
    supportedLanguages.value = []
  }
}

const loadContests = async () => {
  loading.value = true
  error.value = ''
  try {
    const response = await adminContestAPI.list({ page: 0, size: 50 })
    const payload = response?.data?.data
    if (Array.isArray(payload?.content)) {
      contests.value = payload.content
    } else if (Array.isArray(payload)) {
      contests.value = payload
    } else {
      contests.value = []
    }
  } catch (err) {
    error.value = extractErrorMessage(err, 'Failed to load contests')
  } finally {
    loading.value = false
  }
}

const resetForm = () => {
  form.value = initialForm()
  editingId.value = ''
}

const buildPayload = (isEdit) => {
  const rules = parseRules(form.value.rulesText)
  const languages = parseLanguages(form.value.supportedLanguagesText)
  const startIso = toIso(form.value.startTime)
  const endIso = toIso(form.value.endTime)

  if (!startIso || !endIso) {
    throw new Error('Please provide valid Start Time and End Time')
  }

  if (new Date(endIso).getTime() <= new Date(startIso).getTime()) {
    throw new Error('End Time must be after Start Time')
  }

  const startMs = new Date(startIso).getTime()
  const registrationDeadlineIso = new Date(startMs - 60 * 1000).toISOString()

  const payload = {
    title: form.value.title,
    slug: normalizeSlug(form.value.slug),
    description: form.value.description,
    rules,
    contestType: form.value.contestType,
    supportedLanguages: languages,
    registrationDeadline: registrationDeadlineIso,
    startTime: startIso,
    endTime: endIso,
    registrationFee: Number(form.value.registrationFee || 0)
  }

  if (isEdit) {
    payload.status = form.value.status
  }

  return payload
}

const submitContest = async () => {
  submitting.value = true
  error.value = ''
  success.value = ''

  try {
    if (editingId.value) {
      const payload = buildPayload(true)
      await adminContestAPI.update(editingId.value, payload)
      success.value = 'Contest updated successfully'
    } else {
      const payload = buildPayload(false)
      await adminContestAPI.create(payload)
      success.value = 'Contest created in draft. Publish when ready.'
    }

    resetForm()
    await loadContests()
  } catch (err) {
    error.value = extractErrorMessage(err, 'Failed to save contest')
  } finally {
    submitting.value = false
  }
}

const startEdit = (contest) => {
  editingId.value = contest.id
  form.value = {
    title: contest.title || '',
    slug: contest.slug || '',
    description: contest.description || '',
    rulesText: Array.isArray(contest.rules) ? contest.rules.join('\n') : '',
    contestType: contest.contestType || 'INDIVIDUAL',
    supportedLanguagesText: Array.isArray(contest.supportedLanguages)
      ? contest.supportedLanguages.join(', ')
      : '',
    startTime: toLocalDateTimeInput(contest.startTime),
    endTime: toLocalDateTimeInput(contest.endTime),
    registrationFee: contest.registrationFee ?? 0,
    status: contest.status || 'DRAFT'
  }
  success.value = `Editing contest: ${contest.title}`
  error.value = ''

  window.scrollTo({ top: 0, behavior: 'smooth' })
 }

const deleteContest = async (contest) => {
  const confirmed = window.confirm(`Delete contest \"${contest.title}\"?`)
  if (!confirmed) {
    return
  }

  submitting.value = true
  error.value = ''
  success.value = ''
  try {
    await adminContestAPI.delete(contest.id)
    if (editingId.value === contest.id) {
      resetForm()
    }
    success.value = 'Contest deleted successfully'
    await loadContests()
  } catch (err) {
    error.value = extractErrorMessage(err, 'Failed to delete contest')
  } finally {
    submitting.value = false
  }
}

onMounted(async () => {
  await Promise.all([loadSupportedLanguages(), loadContests()])
})
</script>
