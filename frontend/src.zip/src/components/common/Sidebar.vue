<template>
  <aside class="hidden md:block w-64 bg-white dark:bg-dark-800 border-r border-gray-200 dark:border-dark-700 h-[calc(100vh-80px)] overflow-y-auto">
    <nav class="p-6 space-y-2">
      <!-- Dashboard -->
      <RouterLink
        :to="dashboardPath"
        class="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-700 transition"
        :class="{ 'bg-primary-50 dark:bg-primary-900/30 text-primary-600': isRoute(dashboardPath) }"
      >
        <span>📊</span>
        Dashboard
      </RouterLink>

      <!-- Contests -->
      <RouterLink 
        to="/contests"
        class="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-700 transition"
        :class="{ 'bg-primary-50 dark:bg-primary-900/30 text-primary-600': isRoute('/contests') }"
      >
        <span>🎯</span>
        Contests
      </RouterLink>

      <!-- Leaderboard -->
      <RouterLink 
        to="/leaderboard"
        class="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-700 transition"
        :class="{ 'bg-primary-50 dark:bg-primary-900/30 text-primary-600': isRoute('/leaderboard') }"
      >
        <span>🏆</span>
        Leaderboard
      </RouterLink>

      <!-- Admin section -->
      <div v-if="userStore.isAdmin" class="border-t border-gray-200 dark:border-dark-700 mt-4 pt-4">
        <p class="px-4 py-2 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase">Admin</p>

        <RouterLink 
          to="/admin/contests"
          class="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-700 transition"
          :class="{ 'bg-primary-50 dark:bg-primary-900/30 text-primary-600': isRoute('/admin/contests') }"
        >
          <span>📋</span>
          Manage Contests
        </RouterLink>

        <RouterLink 
          to="/admin/users"
          class="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-700 transition"
          :class="{ 'bg-primary-50 dark:bg-primary-900/30 text-primary-600': isRoute('/admin/users') }"
        >
          <span>👥</span>
          Manage Users
        </RouterLink>
      </div>
    </nav>
  </aside>
</template>

<script setup>
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import { useUserStore } from '@/stores'

const route = useRoute()
const userStore = useUserStore()
const dashboardPath = computed(() => (userStore.isAdmin ? '/admin' : '/dashboard'))

const isRoute = (path) => {
  if (path === '/') {
    return route.path === '/'
  }
  return route.path === path || route.path.startsWith(path + '/')
}
</script>
